# **Fungsi Kelas Utama:**

1. Main: Kelas utama yang mengatur alur program. Memiliki fungsi utama main() yang merupakan titik masuk program. Kelas ini juga memiliki metode untuk mencetak informasi kelompok dan proyek.
2. Login: Kelas ini menyimpan informasi login untuk pelanggan dan administrator.
3. Customer: Kelas untuk pengguna sebagai pelanggan. Memungkinkan pelanggan untuk melihat daftar restoran, memesan makanan, dan melihat pesanan.
4. Admin: Kelas untuk pengguna sebagai administrator. Memungkinkan administrator untuk mengelola daftar restoran seperti menambah atau menghapus restoran.
5. Restaurant: Kelas yang merepresentasikan restoran. Menyimpan informasi tentang restoran dan daftar menu yang ditawarkan.
6. Menu: Kelas untuk menyimpan daftar menu makanan dan minuman yang ditawarkan oleh restoran.
7. Order: Kelas untuk merepresentasikan pesanan makanan yang dibuat oleh pelanggan.
