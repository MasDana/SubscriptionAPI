# **Tugas-PBO**

#### Nama : I Gusti Agung Ngurah Lucien Yudistira Purnawarman
#### NIM : 2305551152
#### Kelas : PBO E

- **TUGAS 1**  --> Click directory/Folder Tugas 1_FODOL (FOOD ONLINE)
    > Ida Bagus Agung Wiswa Pramana (2305551092) dan I Gusti Agung Ngurah Lucien Yudistira Purnawarman (2305551152)

- **TUGAS 2**  --> Click directory/Folder Tugas 2_API_Subscription
    > Ida Bagus Agung Wiswa Pramana (2305551092) dan I Gusti Agung Ngurah Lucien Yudistira Purnawarman (2305551152)
